let energy_bar = 184 - 'daytasks.length' * 18.4;
if (energy_bar <= 80) {
    document.getElementById("kitty").src = "/images/Shy_Kitty.gif";
}